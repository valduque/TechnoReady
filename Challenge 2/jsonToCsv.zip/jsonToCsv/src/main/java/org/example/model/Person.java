package com.example.model;

import java.util.List;

/**
 * The {@code Person} class represents an individual record in the dataset.
 * <p>
 * It models a person with basic attributes:
 * <ul>
 *     <li>Name</li>
 *     <li>Age</li>
 *     <li>List of skills</li>
 * </ul>
 *
 * <p>This class is used by {@link com.example.JsonReader} and
 * {@link com.example.CsvWriter} to map JSON and CSV data respectively.</p>
 *
 * @author Val
 * @version 1.0
 */
public class Person {
    private String name;
    private int age;
    private List<String> skills;

    /** Default constructor for JSON deserialization. */
    public Person() {}

    /**
     * Creates a new {@code Person} instance.
     *
     * @param name   person's name
     * @param age    person's age
     * @param skills list of skills
     */
    public Person(String name, int age, List<String> skills) {
        this.name = name;
        this.age = age;
        this.skills = skills;
    }

    /** @return person's name */
    public String getName() { return name; }

    /** @param name sets person's name */
    public void setName(String name) { this.name = name; }

    /** @return person's age */
    public int getAge() { return age; }

    /** @param age sets person's age */
    public void setAge(int age) { this.age = age; }

    /** @return list of skills */
    public List<String> getSkills() { return skills; }

    /** @param skills sets list of skills */
    public void setSkills(List<String> skills) { this.skills = skills; }
}
