package com.example;

import com.example.model.Person;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * The {@code CsvWriter} class handles exporting a list of {@link Person} objects to a CSV file.
 * <p>
 * This class provides methods for writing CSV files using the Apache Commons CSV library,
 * maintaining backward compatibility with previous implementations while allowing new features
 * like custom delimiters.
 *
 * <p><b>Features:</b>
 * <ul>
 *     <li>Writes data into a properly formatted CSV file</li>
 *     <li>Supports configurable delimiters</li>
 *     <li>Preserves the old method for backward compatibility</li>
 * </ul>
 *
 * <p><b>Example usage:</b>
 * <pre>{@code
 * CsvWriter writer = new CsvWriter();
 * writer.writeCsvFile(personList, "output.csv", ',');
 * }</pre>
 *
 * @author Val
 * @version 1.0
 */
public class CsvWriter {

    /**
     * Writes a list of {@link Person} objects to a CSV file using a default semicolon (';') delimiter.
     * <p>
     * This method is preserved for backward compatibility with the previous implementation.
     *
     * @param persons    list of {@link Person} objects to export
     * @param outputPath path of the output CSV file
     * @throws IOException if the file cannot be written
     */
    public void writeCsvFile(List<Person> persons, String outputPath) throws IOException {
        writeCsvFile(persons, outputPath, ';');
    }

    /**
     * Writes a list of {@link Person} objects to a CSV file with a configurable delimiter.
     * <p>
     * The CSV will include a header row ("Name", "Age", "Skills") and will join
     * skill lists into a single string separated by semicolons.
     *
     * @param persons    list of {@link Person} objects to export
     * @param outputPath path of the output CSV file
     * @param delimiter  character used as column separator (e.g., ',' or ';')
     * @throws IOException if an I/O error occurs during writing
     */
    public void writeCsvFile(List<Person> persons, String outputPath, char delimiter) throws IOException {
        CSVFormat format = CSVFormat.DEFAULT
                .withHeader("Name", "Age", "Skills")
                .withDelimiter(delimiter)
                .withQuote('"')
                .withRecordSeparator(System.lineSeparator());

        try (FileWriter writer = new FileWriter(outputPath);
             CSVPrinter printer = new CSVPrinter(writer, format)) {

            for (Person p : persons) {
                String skillsJoined = p.getSkills() == null ? "" : String.join(";", p.getSkills());
                printer.printRecord(p.getName(), p.getAge(), skillsJoined);
            }
            printer.flush();
        }
    }
}