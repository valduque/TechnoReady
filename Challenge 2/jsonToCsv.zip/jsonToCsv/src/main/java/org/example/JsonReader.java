package com.example;

import com.example.model.Person;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

/**
 * The {@code JsonReader} class is responsible for reading JSON files and converting
 * their contents into a list of {@link Person} objects.
 * <p>
 * It supports both file system paths and classpath resources, providing backward
 * compatibility for previous methods used in earlier sprints.
 *
 * <p><b>Features:</b>
 * <ul>
 *     <li>Reads JSON from the file system or classpath</li>
 *     <li>Converts JSON arrays into lists of Person objects</li>
 *     <li>Maintains backward compatibility with older methods</li>
 * </ul>
 *
 * <p><b>Example usage:</b>
 * <pre>{@code
 * JsonReader reader = new JsonReader();
 * List<Person> people = reader.readJsonFile("data.json");
 * }</pre>
 *
 * @author Val
 * @version 1.0
 */
public class JsonReader {
    private final Gson gson = new Gson();

    /**
     * Reads a JSON file located in the classpath and converts it into a list of {@link Person} objects.
     * This method is preserved for backward compatibility.
     *
     * @param resourcePath the path to the resource within the classpath (e.g., "/data.json" or "data.json")
     * @return a list of {@link Person} objects parsed from the JSON file
     * @throws Exception if the resource is not found or cannot be parsed
     */
    public List<Person> readJsonFromClasspath(String resourcePath) throws Exception {
        InputStream is = getClass().getResourceAsStream(resourcePath.startsWith("/") ? resourcePath : "/" + resourcePath);
        if (is == null) {
            throw new Exception("Resource not found on classpath: " + resourcePath);
        }
        try (InputStreamReader reader = new InputStreamReader(is)) {
            Type listType = new TypeToken<List<Person>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (Exception e) {
            throw new Exception("Error parsing JSON from classpath resource: " + resourcePath, e);
        }
    }

    /**
     * Reads a JSON file from a specified file system path.
     * This method is preserved for backward compatibility.
     *
     * @param filePath the path to the JSON file on disk
     * @return a list of {@link Person} objects parsed from the JSON file
     * @throws Exception if the file cannot be found or parsed
     */
    public List<Person> readJsonFromFilePath(String filePath) throws Exception {
        File f = new File(filePath);
        if (!f.exists() || !f.isFile()) {
            throw new Exception("File not found: " + filePath);
        }
        try (FileReader fr = new FileReader(f)) {
            Type listType = new TypeToken<List<Person>>() {}.getType();
            return gson.fromJson(fr, listType);
        } catch (Exception e) {
            throw new Exception("Error reading/parsing JSON from file: " + f.getAbsolutePath(), e);
        }
    }

    /**
     * Reads a JSON file from either a file path or classpath resource.
     * Tries to locate the file in the filesystem first, and if not found,
     * attempts to load it from the classpath.
     *
     * @param pathOrResource the path to the JSON file or the classpath resource name
     * @return a list of {@link Person} objects parsed from the JSON data
     * @throws Exception if the file or resource is not found or cannot be parsed
     */
    public List<Person> readJsonFile(String pathOrResource) throws Exception {
        File f = new File(pathOrResource);
        if (f.exists() && f.isFile()) {
            return readJsonFromFilePath(pathOrResource);
        }

        InputStream is = getClass().getClassLoader().getResourceAsStream(pathOrResource);
        if (is == null) {
            is = getClass().getResourceAsStream(pathOrResource.startsWith("/") ? pathOrResource : "/" + pathOrResource);
        }
        if (is == null) {
            throw new Exception("JSON not found on filesystem nor classpath: " + pathOrResource);
        }

        try (InputStreamReader reader = new InputStreamReader(is)) {
            Type listType = new TypeToken<List<Person>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (Exception e) {
            throw new Exception("Error parsing JSON from resource: " + pathOrResource, e);
        }
    }
}