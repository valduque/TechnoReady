package com.example;

import com.example.model.Person;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The {@code Main} class serves as the entry point of the application.
 * <p>
 * It reads a JSON file containing a list of people, transforms the data into
 * a CSV-compatible structure, and writes it into a CSV file.
 * <p>
 * This class integrates functionalities developed in previous sprints (JSON reading and CSV writing),
 * now extended with command-line arguments and configurable delimiters.
 *
 * <p><b>Command-line usage:</b>
 * <pre>{@code
 * java -jar jsonToCsv.jar input.json output.csv ,
 * }</pre>
 *
 * <p>If no parameters are provided, the program uses default values:</p>
 * <ul>
 *     <li>Input JSON: "data.json"</li>
 *     <li>Output CSV: "output.csv"</li>
 *     <li>Delimiter: ';'</li>
 * </ul>
 *
 * <p><b>Example output:</b></p>
 * <pre>
 * JSON read. Records: 2
 * CSV written to: output.csv
 * </pre>
 *
 * @author Val
 * @version 1.0
 */
public class Main {
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    /**
     * Main execution method.
     * <p>
     * Performs the complete JSON-to-CSV transformation workflow:
     * <ol>
     *     <li>Reads JSON data from the provided file or classpath resource</li>
     *     <li>Maps JSON objects into {@link Person} instances</li>
     *     <li>Writes the data into a CSV file using the specified delimiter</li>
     * </ol>
     *
     * @param args optional command-line arguments:
     *             <ul>
     *                 <li>args[0] → input JSON file path or resource name</li>
     *                 <li>args[1] → output CSV file path</li>
     *                 <li>args[2] → delimiter character</li>
     *             </ul>
     */
    public static void main(String[] args) {
        String input = args.length > 0 ? args[0] : "data.json";
        String output = args.length > 1 ? args[1] : "output.csv";
        char delimiter = (args.length > 2 && args[2].length() > 0) ? args[2].charAt(0) : ';';

        LOGGER.info(() -> "Starting JSON→CSV conversion");
        LOGGER.info(() -> "Input: " + input);
        LOGGER.info(() -> "Output: " + output);
        LOGGER.info(() -> "Delimiter: " + delimiter);

        JsonReader jsonReader = new JsonReader();
        CsvWriter csvWriter = new CsvWriter();

        try {
            List<Person> persons = jsonReader.readJsonFile(input);
            System.out.println("JSON read. Records: " + persons.size());

            csvWriter.writeCsvFile(persons, output, delimiter);
            System.out.println("CSV written to: " + output);

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Processing error", e);
            e.printStackTrace();
        }
    }
}
