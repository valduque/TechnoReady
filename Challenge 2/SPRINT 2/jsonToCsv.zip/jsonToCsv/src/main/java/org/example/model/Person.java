package com.example.model;

import java.util.List;

/**
 * Clase que representa una persona con nombre, edad y habilidades.
 */
public class Person {
    private String name;
    private int age;
    private List<String> skills;

    public Person() {
    }

    public Person(String name, int age, List<String> skills) {
        this.name = name;
        this.age = age;
        this.skills = skills;
    }

    // Getters y setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
}