package com.example;

import com.example.model.Person;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * Clase responsable de escribir listas de objetos en archivos CSV.
 */
public class CsvWriter {

    /**
     * Escribe una lista de personas en un archivo CSV.
     *
     * @param persons   lista de personas
     * @param filePath  ruta del archivo CSV de salida
     * @throws IOException si ocurre un error al escribir el archivo
     */
    public void writeCsvFile(List<Person> persons, String filePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
             CSVPrinter csvPrinter = new CSVPrinter(writer,
                     CSVFormat.DEFAULT.withHeader("name", "age", "skills"))) {

            for (Person person : persons) {
                csvPrinter.printRecord(
                        person.getName(),
                        person.getAge(),
                        String.join(",", person.getSkills())
                );
            }

            csvPrinter.flush();
        } catch (IOException e) {
            throw new IOException("Error al escribir CSV: " + e.getMessage(), e);
        }
    }
}