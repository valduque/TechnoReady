package com.example;

import com.example.model.Person;

import java.util.List;

/**
 * Clase principal que ejecuta la lectura de JSON y la escritura a CSV.
 */
public class Main {

    public static void main(String[] args) {
        String inputJson = "src/main/resources/data.json";
        String outputCsv = "src/main/resources/output.csv";

        JsonReader jsonReader = new JsonReader();
        CsvWriter csvWriter = new CsvWriter();

        try {
            // Leer JSON
            List<Person> persons = jsonReader.readJsonFile(inputJson);
            System.out.println("JSON leído correctamente. Total personas: " + persons.size());

            // Escribir CSV
            csvWriter.writeCsvFile(persons, outputCsv);
            System.out.println("CSV generado correctamente en: " + outputCsv);

        } catch (Exception e) {
            System.err.println("Error durante el proceso:");
            e.printStackTrace();
        }
    }
}