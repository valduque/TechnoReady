package com.example;

import com.example.model.Person;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

/**
 * Clase responsable de leer archivos JSON y convertirlos a listas de objetos Java.
 */
public class JsonReader {

    private final Gson gson = new Gson();

    /**
     * Lee un archivo JSON y lo convierte en una lista de objetos Person.
     *
     * @param filePath ruta del archivo JSON
     * @return lista de personas
     * @throws IOException si ocurre un error al leer el archivo
     */
    public List<Person> readJsonFile(String filePath) throws IOException {
        try (FileReader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Person>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (FileNotFoundException e) {
            throw new IOException("Archivo JSON no encontrado: " + filePath, e);
        } catch (Exception e) {
            throw new IOException("Error al parsear JSON: " + e.getMessage(), e);
        }
    }
}